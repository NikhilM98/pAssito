function closecover() {
    document.getElementById("cover").className="cover-fade";
    setTimeout(function() {
        document.getElementById("cover").style.display="none";
    }, 450);
};